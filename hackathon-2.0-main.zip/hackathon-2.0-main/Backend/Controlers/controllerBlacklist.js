import { databasePostgres } from "../Database/databasePostgres.js";

const db = new databasePostgres();

export const getBlacklist = async (req, res) => {
    try {
        const blacklist = await db.listBlacklist();
        res.json(blacklist);
    } catch (error) {
        console.error("Error fetching blacklist:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

export const addToBlacklist = async (req, res) => {
  const { nome, cpf, motivo } = req.body;
  try {
    await db.addToBlacklist(nome, cpf, motivo);
    res.status(201).json({ message: "Adicionado à blacklist com sucesso" });
  } catch (error) {
    console.error("Error adding to blacklist:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
}

export const removeFromBlacklist = async (req, res) => {
    const { cpf } = req.params;
    try {
        await db.removeFromBlacklist(cpf);
        res.json({ message: "Removido da blacklist com sucesso" });
    } catch (error) {
        console.error("Error removing from blacklist:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}
