import { databasePostgres } from "../Database/databasePostgres.js";
import * as sse from "./sse.js";
const db = new databasePostgres();

export const getConvidados = async (req, res) => {
    const { search } = req.query;

    try{
        const convidados = await db.listConvidados(search);
        res.json(convidados);
    } catch (error) {
        console.error("Error fetching convidados:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
}

export const createConvidado = async (req, res) => {
    try {
        const { nome, cpf, email, area } = req.body;

        // Verifica se CPF já existe para evitar erro de unique constraint
        const existing = await db.getConvidadoByCpf(cpf);
        if (existing) {
            return res.status(409).json({ error: "Convidado com esse CPF já existe" });
        }

        const convidado = await db.createConvidado(nome, cpf, email, area);
        // If foto was provided on creation, save it
        if (req.body && req.body.foto) {
            try {
                await db.updateConvidado(cpf, { foto: req.body.foto });
                // attach foto to response object for SSE
                convidado.foto = req.body.foto;
            } catch (e) {
                console.warn('Não foi possível salvar foto no momento de criação:', e);
            }
        }

        // Emit event to SSE clients about new convidado
        try {
            const payload = { nome, cpf, email, area, foto: convidado.foto || null };
            sse.sendEvent('novo-convidado', payload);
        } catch (e) {
            console.warn('Falha ao enviar evento SSE:', e);
        }
        res.status(201).json(convidado); // já inclui o QR Code
    } catch (error) {
        console.error("Error creating convidado:", error);
        // Se o banco lançar unique-constraint por alguma condição de corrida, devolve 409
        if (error && error.code === '23505') {
            return res.status(409).json({ error: 'CPF já cadastrado' });
        }
        res.status(500).json({ error: "Internal Server Error" });
    }
}

export const updateConvidado = async (req, res) => {
  const { cpf } = req.params;
  try {
        // Debug: log if foto is present and its size
        if (req.body && req.body.foto) {
            const len = typeof req.body.foto === 'string' ? req.body.foto.length : 0;
            console.log(`Recebendo foto para CPF ${cpf}, tamanho: ${len}`);
        }

        await db.updateConvidado(cpf, req.body);
        
        // Se foi atualizada uma foto, emite evento SSE para atualizar reconhecimento facial
        if (req.body && req.body.foto) {
            try {
                const convidado = await db.getConvidadoByCpf(cpf);
                if (convidado) {
                    sse.sendEvent('foto-atualizada', {
                        cpf: convidado.cpf,
                        nome: convidado.nome,
                        email: convidado.email,
                        area: convidado.area,
                        foto: req.body.foto
                    });
                    console.log('Evento SSE enviado: foto-atualizada para', cpf);
                }
            } catch (e) {
                console.warn('Falha ao enviar evento SSE de foto atualizada:', e);
            }
        }
        
    res.json({ message: "Convidado atualizado com sucesso" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const deleteConvidado = async (req, res) => {
    const { cpf } = req.params;
    try {
        await db.deleteConvidado(cpf);
        res.json({ message: "Convidado deletado com sucesso" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export const moveConvidadoToArea = async (req, res) => {
    const { cpf } = req.params;
    const { area } = req.body;

    try {
        await db.moveConvidadoToArea(cpf, area);
        res.json({ message: "Convidado movido com sucesso" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export const countConvidadoPorArea = async (req, res) => {
    try {
        const counts = await db.countConvidadoPorArea();
        res.json(counts);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

// ------------------- CHECK-INS -------------------
export const registrarCheckin = async (req, res) => {
    const { cpf } = req.params;
    const { area } = req.body || {};
    
    try {
        // Busca os dados do convidado
        const convidado = await db.getConvidadoByCpf(cpf);
        
        if (!convidado) {
            return res.status(404).json({ error: 'Convidado não encontrado' });
        }

        // Registra o check-in
        await db.registrarCheckin(cpf, convidado.nome, area || convidado.area);
        
        res.json({ 
            message: 'Check-in registrado com sucesso',
            nome: convidado.nome,
            cpf: cpf
        });
    } catch (error) {
        console.error('Erro ao registrar check-in:', error);
        res.status(500).json({ error: 'Erro ao registrar check-in' });
    }
}

export const obterEstatisticas = async (req, res) => {
    try {
        const stats = await db.obterEstatisticasEvento();
        res.json(stats);
    } catch (error) {
        console.error('Erro ao obter estatísticas:', error);
        res.status(500).json({ error: 'Erro ao obter estatísticas' });
    }
}
