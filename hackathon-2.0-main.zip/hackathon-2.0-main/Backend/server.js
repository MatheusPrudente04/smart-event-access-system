import express from "express";
import cors from "cors";
import 'dotenv/config';

import routesConvidados from "./routes/routesConvidados.js";
import routesBlacklist from "./routes/routesBlacklist.js";

const app = express();
app.use(cors());
// Increase JSON body size limit to allow base64 images
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

app.use("/convidados", routesConvidados);
app.use("/blacklist", routesBlacklist);


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));



