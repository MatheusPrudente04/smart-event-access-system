import express from "express";

import { getBlacklist, addToBlacklist,  removeFromBlacklist } from "../Controlers/controllerBlacklist.js";

const router = express.Router();

router.get("/", getBlacklist);
router.post("/", addToBlacklist);
router.delete("/:cpf", removeFromBlacklist);


export default router;