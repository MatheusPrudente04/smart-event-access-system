import express from "express";
import { 
  countConvidadoPorArea, createConvidado, deleteConvidado, getConvidados, moveConvidadoToArea, updateConvidado,
  registrarCheckin, obterEstatisticas
} from "../Controlers/controllerConvidados.js";
import { addClient } from "../Controlers/sse.js";

const router = express.Router();

router.get("/", getConvidados);
router.post("/", createConvidado);
router.put("/:cpf", updateConvidado);
router.delete("/:cpf", deleteConvidado);

// SSE events
router.get('/events', addClient);

// Movimentação e contagem por área
router.put("/:cpf/move", moveConvidadoToArea);
router.get("/count/by-area", countConvidadoPorArea);

// Check-in
router.post("/:cpf/checkin", registrarCheckin);

// Estatísticas do evento
router.get("/stats", obterEstatisticas);

export default router;
