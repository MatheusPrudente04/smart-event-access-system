import { sql } from "./db.js";
import QRCode from "qrcode";

export class databasePostgres {

  // ------------------- CONVIDADOS -------------------
  async listConvidados(search) {
    if (search) {
      return await sql`SELECT * FROM convidados WHERE nome ILIKE ${'%' + search + '%'}`;
    } 
    return await sql`SELECT * FROM convidados`;
  }

  async getConvidadoByCpf(cpf) {
    const result = await sql`SELECT * FROM convidados WHERE cpf = ${cpf}`;
    return result && result.length ? result[0] : null;
  }

  async createConvidado(nome, cpf, email, area) {
    // Cria dados do QR
    const qrData = JSON.stringify({ nome, cpf,});
    const qrCodeBase64 = await QRCode.toDataURL(qrData);

    // Insere no banco
    await sql`
        INSERT INTO convidados (nome, cpf, email, area, qr_code)
        VALUES (${nome}, ${cpf}, ${email}, ${area}, ${qrCodeBase64})
    `;

    return { nome, cpf, email, area, qrCode: qrCodeBase64 };
}

  async updateConvidado(cpf, data) {
    // Build SET clauses using parameterized query (sql.query) to avoid tagged-template misuse
    const setClauses = [];
    const params = [];
    let idx = 1;

    if (data.nome !== undefined) {
      setClauses.push(`nome = $${idx}`);
      params.push(data.nome);
      idx++;
    }
    if (data.email !== undefined) {
      setClauses.push(`email = $${idx}`);
      params.push(data.email);
      idx++;
    }
    if (data.area !== undefined) {
      setClauses.push(`area = $${idx}`);
      params.push(data.area);
      idx++;
    }
    if (data.foto !== undefined) {
      setClauses.push(`foto = $${idx}`);
      params.push(data.foto);
      idx++;
    }

    if (setClauses.length === 0) return; // Nothing to update

    // Add cpf as last parameter
    params.push(cpf);
    const cpfParamIndex = params.length; // position of cpf in params (1-based)

    const text = `UPDATE convidados SET ${setClauses.join(', ')} WHERE cpf = $${cpfParamIndex}`;
    // execute using sql.query(text, params)
    await sql.query(text, params);
  }

  async deleteConvidado(cpf) {
    return await sql`DELETE FROM convidados WHERE cpf = ${cpf}`;
  }

  async moveConvidadoToArea(cpf, area) {
    await sql`
      UPDATE convidados
      SET area = ${area}
      WHERE cpf = ${cpf}
    `;
  }

  async countConvidadoPorArea() {
    return await sql`
      SELECT area, COUNT(*) AS total
      FROM convidados
      GROUP BY area
    `;
  }

  // ------------------- CHECK-INS -------------------
  async registrarCheckin(cpf, nome, area) {
    await sql`
      INSERT INTO checkins (cpf, nome, area)
      VALUES (${cpf}, ${nome}, ${area})
    `;
  }

  async contarCheckinsTotal() {
    const result = await sql`
      SELECT COUNT(DISTINCT cpf) as total
      FROM checkins
    `;
    return result[0]?.total || 0;
  }

  async contarCheckinsPorArea() {
    return await sql`
      SELECT area, COUNT(DISTINCT cpf) AS total
      FROM checkins
      WHERE area IS NOT NULL
      GROUP BY area
    `;
  }

  async obterEstatisticasEvento() {
    // Total de convidados cadastrados
    const totalConvidados = await sql`
      SELECT COUNT(*) as total FROM convidados
    `;

    // Total de pessoas que fizeram check-in (CPFs únicos)
    const totalCheckins = await sql`
      SELECT COUNT(DISTINCT cpf) as total FROM checkins
    `;

    // Check-ins por área
    const checkinsPorArea = await sql`
      SELECT area, COUNT(DISTINCT cpf) AS total
      FROM checkins
      WHERE area IS NOT NULL
      GROUP BY area
    `;

    // Convidados por área
    const convidadosPorArea = await sql`
      SELECT area, COUNT(*) AS total
      FROM convidados
      WHERE area IS NOT NULL
      GROUP BY area
    `;

    const totalConv = parseInt(totalConvidados[0]?.total || 0);
    const totalCheck = parseInt(totalCheckins[0]?.total || 0);
    const percentualPresenca = totalConv > 0 ? ((totalCheck / totalConv) * 100).toFixed(2) : 0;

    return {
      totalConvidados: totalConv,
      totalCheckIns: totalCheck,
      percentualPresenca: parseFloat(percentualPresenca),
      checkinsPorArea: checkinsPorArea.map(row => ({
        area: row.area,
        total: parseInt(row.total)
      })),
      convidadosPorArea: convidadosPorArea.map(row => ({
        area: row.area,
        total: parseInt(row.total)
      }))
    };
  }

  // ------------------- BLACKLIST -------------------
  async listBlacklist() {
    return await sql`SELECT * FROM blacklist`;
  }

  async addToBlacklist(nome,cpf, motivo) {
    await sql`INSERT INTO blacklist (nome, cpf, motivo) VALUES (${nome}, ${cpf}, ${motivo})`;
    return { cpf, motivo };
  }

  async removeFromBlacklist(cpf) {
    return await sql`DELETE FROM blacklist WHERE cpf = ${cpf}`;
  }
}
