import { sql } from "./db.js";

const testConnection = async () => {
  try {
    const result = await sql`SELECT version()`;
    console.log("Conexão com o banco OK!");
    console.log("Versão do PostgreSQL:", result[0].version);
    process.exit(0);
  } catch (error) {
    console.error("Erro ao conectar no banco:", error);
    process.exit(1);
  }
};

testConnection();