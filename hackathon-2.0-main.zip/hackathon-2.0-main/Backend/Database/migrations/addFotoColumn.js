import { sql } from "../db.js";

const addFotoColumn = async () => {
  try {
    // Adiciona coluna foto se não existir
    await sql`
      ALTER TABLE convidados
      ADD COLUMN IF NOT EXISTS foto TEXT;
    `;

    console.log("Coluna 'foto' adicionada com sucesso!");
    process.exit(0);
  } catch (error) {
    console.error("Erro ao adicionar coluna 'foto':", error);
    process.exit(1);
  }
};

addFotoColumn();