import { neon } from "@neondatabase/serverless";

// Passando a URL diretamente
export const sql = neon(
  "postgresql://neondb_owner:npg_T7fC4wEoZuQK@ep-bitter-sound-ad54shcm-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
);

