import { sql } from "./db.js";

const createTables = async () => {
  try {
    // Tabela de convidados
    await sql`
      CREATE TABLE IF NOT EXISTS convidados (
        nome TEXT NOT NULL,
        cpf TEXT UNIQUE NOT NULL,
        email TEXT,
        area TEXT,
        foto TEXT,
        qr_code TEXT
      );
    `;

    // Tabela de check-ins (registra cada entrada no evento)
    await sql`
      CREATE TABLE IF NOT EXISTS checkins (
        id SERIAL PRIMARY KEY,
        cpf TEXT NOT NULL,
        nome TEXT,
        area TEXT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;

    console.log("Tabelas criadas com sucesso!");
    process.exit(0);
  } catch (error) {
    console.error("Erro ao criar tabelas:", error);
    process.exit(1);
  }
};

createTables();
